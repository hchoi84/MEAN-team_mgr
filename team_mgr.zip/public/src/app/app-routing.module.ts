import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlayersComponent } from './players/players.component';
import { PlayersListComponent } from './players-list/players-list.component';
import { PlayersAddComponent } from './players-add/players-add.component';
import { StatusComponent } from './status/status.component';


const routes: Routes = [
  { path: "players", component: PlayersComponent, children: [
    { path: "list", component: PlayersListComponent },
    { path: "add", component: PlayersAddComponent },
  ]},
  { path: "status", component: StatusComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
