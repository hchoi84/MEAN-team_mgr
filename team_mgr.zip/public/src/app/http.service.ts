import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // dependency injection

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) { }

  createPlayer(player){ return this._http.post("/players", player); }
  getPlayers(){ return this._http.get("/players"); }
  getPlayer(id){ return this._http.get(`/players/${id}`); }
  updatePlayer(player){ return this._http.put(`/players/${player._id}`, player); }
  deletePlayer(id){ return this._http.delete(`/players/${id}`); }
}
