import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';
import { observable } from 'rxjs';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-players-list',
  templateUrl: './players-list.component.html',
  styleUrls: ['../app.component.css', './players-list.component.css']
})
export class PlayersListComponent implements OnInit {
  constructor(
    private _httpService: HttpService,
    private _route: ActivatedRoute,
    private _router: Router,
  ) {}

  private allPlayers: any;

  ngOnInit() {
    let observable = this._httpService.getPlayers();
    observable.subscribe(data => {
      this.allPlayers = data;
    });
  }

  deletePlayer(id){
    let confirmation = confirm("Are you sure?");
    if (confirmation){
      let observable = this._httpService.deletePlayer(id);
      observable.subscribe(data => {
        this.ngOnInit();
      });
    }
  }
}
