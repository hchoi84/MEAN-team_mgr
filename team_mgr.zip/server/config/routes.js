const player = require("../controllers/players.js");

module.exports = app => {
    app.get("/players", (req, res) => { player.getPlayers(req, res); })
    app.get("/players/:id", (req, res) => { player.getPlayer(req, res); })
    app.post("/players", (req, res) => { player.create(req, res); })
    app.put("/players/:id", (req, res) => { player.editPlayer(req, res); })
    app.delete("/players/:id", (req, res) => { player.deletePlayer(req, res); })
}